Google drive link for the data collected from the kaggle

https://drive.google.com/file/d/1Se9pH4-OQao374Kes9oBuuIzYJ9Ve0I4/view?usp=drive_link
