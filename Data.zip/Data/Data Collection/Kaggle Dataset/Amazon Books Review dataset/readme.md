# Amazon Book Review dataset
- The code used here is same as the Amzon books dataset.
- Two files might get downloaded but we are using only one file 'books_data.csv'.
- Columns - Title, description, author, image , preview link, publisher, publishing date, infolink, categories, rating count.
- Number of records = 212404
- Link to access the dataset - https://www.kaggle.com/datasets/mohamedbakhet/amazon-books-reviews/data?select=Books_rating.csv
